<?php if($errors->any()): ?>
    <div class="border border-danger text-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php echo csrf_field(); ?>

<h4>Personal Details</h4>
<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="name">Name</label>
        <?php if(isset($enquiry)): ?>
            <input type="text" class="form-control text-capitalize" id="name" name="name" placeholder="Full Name"
            value="<?php echo e($enquiry->name); ?>" required>
        <?php else: ?>
            <input type="text" class="form-control text-capitalize" id="name" name="name" placeholder="Full Name"
            value="<?php if(isset($client)): ?><?php echo e($client->name); ?><?php else: ?><?php echo e(old('name')); ?><?php endif; ?>" required>
        <?php endif; ?>
    </div>

   

    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="email">Email</label>
        <?php if(isset($enquiry)): ?>
            <input type="email" class="form-control" id="email" name="email" placeholder="user@example.com"
            value="<?php echo e($enquiry->email); ?>">
        <?php else: ?>
            <input type="email" class="form-control" id="email" name="email" placeholder="user@example.com"
            value="<?php if(isset($client)): ?><?php echo e($client->email); ?><?php else: ?><?php echo e(old('email')); ?><?php endif; ?>">
        <?php endif; ?>
    </div>

    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="contact_no">Contact Number</label>
        <?php if(isset($enquiry)): ?>
            <input type="tel" class="form-control" id="contact_no" name="contact_no" placeholder="+910123456789" maxlength="10" pattern="{0-9}" 
            value="<?php echo e($enquiry->contact_no); ?>" required>
        <?php else: ?>
            <input type="tel" class="form-control" id="contact_no" name="contact_no" placeholder="+910123456789" maxlength="10" pattern="{0-9}" 
            value="<?php if(isset($client)): ?><?php echo e($client->contact_no); ?><?php else: ?><?php echo e(old('contact_no')); ?><?php endif; ?>" required>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="subject">Subject</label>
        <?php if(isset($enquiry)): ?>
            <textarea class="form-control" id="subject" name="subject" placeholder="Subject"
            ><?php echo e($enquiry->subject); ?></textarea>
        <?php else: ?>
            <textarea class="form-control" id="subject" name="subject" placeholder="Subject"
            ><?php if(isset($client)): ?><?php echo e($client->subject); ?><?php else: ?><?php echo e(old('subject')); ?><?php endif; ?></textarea>
        <?php endif; ?>
    </div>

    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="rating">Rating</label>
        <select class="form-control" id="rating" name="rating" required>
            <option value="1">&starf;</option>
            <option value="2">&starf;&starf;</option>
            <option value="3">&starf;&starf;&starf;</option>
            <option value="4">&starf;&starf;&starf;&starf;</option>
            <option value="5">&starf;&starf;&starf;&starf;&starf;</option>
        </select>
    </div>
</div>

<div class="row">
    <div class="form-group form-check ml-3">
        <?php if(isset($enquiry)): ?>
            <input type='checkbox' class="form-check-input" name='is_active' checked disabled />
        <?php else: ?>
            <?php if(isset($client)): ?>
                <input type='checkbox' class="form-check-input" name='is_active' <?php if(isset($client->is_active)): ?><?php if($client->is_active): ?>checked <?php else: ?> <?php endif; ?> <?php endif; ?> />
            <?php else: ?>
                <input type='checkbox' class="form-check-input" name='is_active' checked />
            <?php endif; ?>
        <?php endif; ?>
        <label class="form-check-label" for="is_active">Is Active?</label>
    </div>
</div>
<br><br>

<h4>Booking Details</h4>
<div class="row">
	<div class="form-group col-sm-3">
	 <label class="text-capitalize" for="carpet_area">Booking Date</label>
			<input type="text" class="form-control" id="carpet_area" name="booking_date" placeholder="Booking_date"
			<?php if(isset($client)): ?>value="<?php $originalDate = $client->created_at;
			echo $newDate = date("d-m-Y", strtotime($originalDate));?>"<?php endif; ?> >
	</div>
</div>
<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="project">Project</label>
        <select class="form-control js-example-basic-single" id="project" name="project" required>
            <?php if(isset($enquiry)): ?>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($project->id); ?>" <?php if(isset($enquiry->project->id)): ?><?php if($project->id == $enquiry->project->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($project->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($project->id); ?>" <?php if(isset($client->project->id)): ?> <?php if($project->id == $client->project->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($project->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
    </div>

    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="configuration">Configuration</label>
        <select class="form-control js-example-basic-single" id="configuration" name="configuration" required>
            <?php if(isset($enquiry)): ?>
                <?php $__currentLoopData = $configurations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $configuration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($configuration->id); ?>" <?php if(isset($enquiry->configuration->id)): ?><?php if($configuration->id == $enquiry->configuration->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($configuration->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php $__currentLoopData = $configurations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $configuration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($configuration->id); ?>" <?php if(isset($client->configuration->id)): ?> <?php if($configuration->id == $client->configuration->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($configuration->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
    </div>

    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="carpet_area">Carpet Area (Sq. Ft.)/Super Area</label>
        <input type="number" step="0.01" class="form-control" id="carpet_area" name="carpet_area" placeholder="Carpet area"
        <?php if(isset($client)): ?>value="<?php echo e($client->carpet_area); ?>"<?php endif; ?> >
    </div>

    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="booking_amount">Booking Amount (<?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?>)</label>
        <input type="number" step="0.01" class="form-control" id="booking_amount" name="booking_amount" placeholder="Booking amount"
        <?php if(isset($client)): ?>value="<?php echo e($client->booking_amount); ?>"<?php endif; ?> required>
    </div>
</div>
<div class="row">
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="agreement_value">Unit No</label>
        <input type="number" class="form-control" id="unit_no" name="unit_no" placeholder="Unit Number"
        <?php if(isset($client)): ?>value="<?php echo e($client->unit_no); ?>"<?php endif; ?> >
    </div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="agreement_value">Floor No</label>
        <input type="number" class="form-control" id="floor_no" name="floor_no" placeholder="Floor Number"
        <?php if(isset($client)): ?>value="<?php echo e($client->floor_no); ?>"<?php endif; ?> >
    </div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="agreement_value">Tower No</label>
        <input type="number" class="form-control" id="tower_no" name="tower_no" placeholder="Tower Number"
        <?php if(isset($client)): ?>value="<?php echo e($client->tower_no); ?>"<?php endif; ?> >
    </div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="agreement_value">Actual Amount (<?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?>)</label>
        <input type="number" step="0.01" class="form-control" id="actual_amount" name="actual_amount" placeholder="Actual Amount"
        <?php if(isset($client)): ?>value="<?php echo e($client->actual_amount); ?>"<?php endif; ?> required>
    </div>
</div>
<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="agreement_value">Agreement Value (<?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?>)</label>
        <input type="number" step="0.01" class="form-control" id="agreement_value" name="agreement_value" placeholder="Agreement value"
        <?php if(isset($client)): ?>value="<?php echo e($client->agreement_value); ?>"<?php endif; ?> required>
    </div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="agreement_value">Payment Plan </label>
        <input type="text"  class="form-control" id="payment_plan" name="payment_plan" placeholder="Payment Plan"
        <?php if(isset($client)): ?>value="<?php echo e($client->payment_plan); ?>"<?php endif; ?> required>
    </div>

    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="payment_mode">Payment Mode</label>
        <select class="form-control js-example-basic-single" id="payment_mode" onchange="otherSelect(event)"  name="payment_mode" required>
            <?php $__currentLoopData = $payment_modes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_mode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if(isset($client)): ?><?php if($client->payment_mode->id === $payment_mode->id): ?> selected <?php endif; ?> <?php endif; ?>
                value="<?php echo e($payment_mode->id); ?>"><?php echo e($payment_mode->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
		<div id="otherBox" style="visibility: hidden;">
		 <input name="cheque_no" type="text" placeholder="Enter Cheque no" class="form-control" /> 
		</div>
    </div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="attachment">Payment Proof</label>
        <input type="file" class="form-control" id="attachment" name="attachment">
    </div>
</div>

<?php if( auth()->user()->hasRole('Admin') == true): ?>
<br><br>

<h4>Company Incentive Details</h4>
<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="brokerage_percent">Incentive (%)</label>
        <input type="number" step="0.01" class="form-control" id="brokerage_percent" name="incentive_percent"
        placeholder="Incentive percent" value="<?php if(isset($incentive->incentive_percentage)): ?><?php echo e($incentive->incentive_percentage); ?><?php endif; ?>">
    </div>

    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="brokerage_amount">Incentive Amount (<?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?>)</label>
        <input type="number" step="0.01" class="form-control" id="brokerage_amount" name="incentive_amount"
        placeholder="Incentive Amount" value="<?php if(isset($incentive->incentive_amount)): ?><?php echo e($incentive->incentive_amount); ?><?php endif; ?>" >
    </div>
	
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="brokerage_remark">Remark</label>
        <input type="text" class="form-control" id="brokerage_remark" name="incentive_remark" placeholder="Remarks" value="<?php if(isset($incentive->remarks)): ?><?php echo e($incentive->remarks); ?><?php endif; ?>">
    </div>
</div>

<h4>Employee Incentive Details</h4>
<div class="row">
		<div class=" mt-3" data-x-wrapper="emp_incentive">
		<?php if(isset($emp_incentive)): ?>
		<?php $__currentLoopData = $emp_incentive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="d-flex my-2" data-x-group>
					<div class="form-group col-sm-3">
							<label class="text-capitalize" for="project">Incentive For</label>
							<select class="form-control " id="project" name="user_id" >
									<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($user->id); ?>" <?php if($user->id == $inc->user_id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($user->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							   
							</select>
						</div>
						<div class="form-group col-sm-3">
					<label class="text-capitalize" for="incentive_employee_percent">Incentive (%)</label>
					<input type="number" step="0.01" class="form-control" id="incentive_employee_percent" name="incentive_employee_percent"
					placeholder="Incentive percent" value="<?php echo e($inc->incentive_percentage); ?>">
				</div>
				 <div class="form-group col-sm-3">
				<label class="text-capitalize" for="incentive_employee_amount">Incentive Amount (<?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?>)</label>
				<input type="number" step="0.01" class="form-control" id="incentive_employee_amount" name="incentive_employee_amount"
				placeholder="Incentive Amount" value="<?php echo e($inc->incentive_amount); ?>">
				</div>

				<div class="ml-2">
					<button type="button" class="btn btn-danger remove_dup" data-remove-btn>-</button>
					<button type="button" class="btn btn-primary add_dup" data-add-btn>+</button>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
				<div class="d-flex my-2" data-x-group>
					<div class="form-group col-sm-3">
							<label class="text-capitalize" for="project">Incentive For</label>
							<select class="form-control " id="project" name="user_id" >
									<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($user->id); ?>" ><?php echo e($user->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							   
							</select>
						</div>
						<div class="form-group col-sm-3">
					<label class="text-capitalize" for="brokerage_percent">Incentive (%)</label>
					<input type="number" step="0.01" class="form-control" id="incentive_employee_percent" name="incentive_employee_percent"
					placeholder="Incentive percent" value="">
				</div>
				 <div class="form-group col-sm-3">
				<label class="text-capitalize" for="brokerage_amount">Incentive Amount (<?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?>)</label>
				<input type="number" step="0.01" class="form-control" id="incentive_employee_amount" name="incentive_employee_amount"
				placeholder="Incentive Amount" value="">
				</div>

				<div class="ml-2"><br>
					<button type="button" class="btn btn-danger remove_dup" data-remove-btn>-</button>
					<button type="button" class="btn btn-primary add_dup" data-add-btn>+</button>
				</div>
			</div>
			<?php endif; ?>
		</div>
	
</div>
<?php endif; ?>

<div class="form-group">
<input type="hidden" name="lead_id" value="<?php if(isset($enquiry->id)): ?><?php echo e($enquiry->id); ?><?php endif; ?>">
    <button type="submit" class="btn btn-success">
        <?php if(isset($enquiry)): ?>
            Save
        <?php else: ?>
            <?php if(isset($client)): ?>
                Update
            <?php else: ?>
                Create
            <?php endif; ?>
        <?php endif; ?>
    </button>
    <a class="btn btn-danger ml-3" href="<?php echo e(route('clients.index')); ?>">Cancel</a>
</div>
<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="<?php echo e(url('/').'/js/jquery.replicate.js'); ?>"></script>

<script>
		
		jQuery(function(){
  jQuery("input[name='contact_no']").on('input', function (e) {
    jQuery(this).val($(this).val().replace(/[^0-9]/g, ''));
  });
});
function otherSelect(event) {
	
 var other = document.getElementById("otherBox");
 if ($( "#payment_mode  option:selected" ).text() == "Cheque") {
 other.style.visibility = "visible";
 }
 else {
 other.style.visibility = "hidden";
 }
 }

 
 const selector = '[data-x-wrapper]';
        let options = {
            disableNaming: '[data-disable-naming]',
            wrapper: selector,
            group: '[data-x-group]',
            addBtn: '[data-add-btn]',
            removeBtn: '[data-remove-btn]'
        };
 
        $(selector).replicate(options);

</script><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/clients/form.blade.php ENDPATH**/ ?>