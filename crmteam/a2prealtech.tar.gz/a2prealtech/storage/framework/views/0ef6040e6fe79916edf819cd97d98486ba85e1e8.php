<?php $__env->startSection('title', 'Edit Invoice'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit Invoice</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('invoices.update', ['id' => $invoice->id])); ?>">
        <?php echo $__env->make('invoices.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/s2.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/brokerage_calculator.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/invoices/edit.blade.php ENDPATH**/ ?>