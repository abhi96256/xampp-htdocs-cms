<?php if($errors->any()): ?>
    <div class="border border-danger text-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php echo csrf_field(); ?>

<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="payer">Payer</label>
        <input type="text" class="form-control text-capitalize" id="payer" name="payer" placeholder="Payer name"
        value="<?php if(isset($due)): ?><?php echo e($due->payer); ?><?php else: ?><?php echo e(old('payer')); ?><?php endif; ?>" required>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="amount">Amount (<?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?>)</label>
        <input type="number" step="0.01" class="form-control text-capitalize" id="amount" name="amount"
        value="<?php if(isset($due)): ?><?php echo e($due->amount); ?><?php else: ?><?php echo e(old('amount')); ?><?php endif; ?>" required>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="due_date">Due Date</label>
        <input type="date" class="form-control" id="due_date" name="due_date"
        value="<?php if(isset($due)): ?><?php echo e($due->due_date->format('Y-m-d')); ?><?php else: ?><?php echo e(old('due_date')); ?><?php endif; ?>" required>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="payment_mode">Payment Mode</label>
        <select class="form-control js-example-basic-single" id="payment_mode" name="payment_mode" required>
            <?php $__currentLoopData = $payment_modes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_mode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($payment_mode->id); ?>" <?php if(isset($due)): ?> <?php if($payment_mode->id == $due->payment_mode->id): ?> selected <?php endif; ?> <?php endif; ?>>
                    <?php echo e($payment_mode->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="remark">Remark</label>
        <input type="text" class="form-control text-capitalize" id="remark" name="remark" placeholder="Remark"
        value="<?php if(isset($due)): ?><?php echo e($due->remark); ?><?php else: ?><?php echo e(old('remark')); ?><?php endif; ?>">
    </div>
</div>

<div class="form-group">
    <input type="submit" class="btn btn-success" value="<?php if(isset($due)): ?> Update <?php else: ?> Create <?php endif; ?>">
    <a class="btn btn-danger ml-3" href="<?php echo e(route('dues.index')); ?>">Cancel</a>
</div>
<?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/dues/form.blade.php ENDPATH**/ ?>