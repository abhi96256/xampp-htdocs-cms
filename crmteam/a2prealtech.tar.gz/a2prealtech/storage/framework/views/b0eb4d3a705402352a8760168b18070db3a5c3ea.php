<?php $__env->startSection('title', 'Add New Client'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Add New Client</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form method="post" action="<?php echo e(route('clients.store')); ?>" enctype="multipart/form-data">
        <?php echo $__env->make('clients.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/s2.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/brokerage_calculator.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/clients/create.blade.php ENDPATH**/ ?>