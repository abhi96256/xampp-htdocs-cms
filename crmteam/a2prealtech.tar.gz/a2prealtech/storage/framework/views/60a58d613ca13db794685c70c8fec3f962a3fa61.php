<?php $__env->startSection('title', 'Incentive Reports'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Incentive Reports</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card px-3 py-2">
        <!--<div class="my-3">
			<div class="float-right ml-2">
			<form method="post" action="<?php echo e(route('enquiries.date_range')); ?>">
			<?php echo csrf_field(); ?>
			<input type="submit" class="btn btn-success text-uppercase float-right ml-2" name="Filter"  />
			<input type="text" class=" float-right" name="daterange" Placeholder="Date Range Filter" />
			</div>
			<div class="float-right ml-2"> <label>Date Range</label>
			</form>
			</div>
           
        </div>
        <br>
-->
        <div class="table-responsive">
            <table class="table" id="example">
                <thead class="thead-dark">
                    <tr>
                        <th class="text-uppercase" scope="col">#</th>
                        <th class="text-uppercase" scope="col">Client name</th>
                        <th class="text-uppercase" scope="col">Project Name</th>
                        <th class="text-uppercase" scope="col">User </th>
                        <th class="text-uppercase" scope="col">Incentive Percentage</th>
                        <th class="text-uppercase" scope="col">Incentive Amount</th>
                    </tr>
                </thead>
                <tbody>
				<?php 
				
				 $i= 0;?>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php 
				 $i++;?>
                    <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($d['client_name']); ?></td>
                        <td><?php echo e($d['lead_id']); ?></td>
                        <td><?php echo e($d['user_name']); ?></td>
                        <td><?php echo e($d['incentive_percentage']); ?></td>
                        <td><?php echo e($d['incentive_amount']); ?></td>
                    </tr>
                        
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
          
        </div>

        
        <div class="mt-4">
          
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/table_utils.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/enquiry_lost.js')); ?>"></script>
	<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>

	<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />
<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/3.0.2/js/dataTables.buttons.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.dataTables.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.print.min.js"></script>
	<script>
	
	jQuery(function($){
		$('input[name="daterange"]').daterangepicker(
		{
			locale: {
			  format: 'YYYY-MM-DD'
			},
			startDate: '2024-05-01',
			endDate: '2024-05-31'
		}
		);
		
		 
   
	});
	new DataTable('#example', {
    layout: {
        topStart: {
            buttons: [ 'csv', 'excel', 'pdf', 'print']
        }
    }
});
</script>
<style>
.dt-search{
	display:none;
}
.dt-layout-row {
    text-align: right;
}
.dt-layout-row button {
    background-color: #000;
    color: #fff;
    padding: 5px 10px;
    margin-bottom: 10px;
}
</style>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/reports/cincentive.blade.php ENDPATH**/ ?>