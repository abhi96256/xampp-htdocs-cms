<?php $__env->startSection('title', 'All Dues'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>All Dues</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card px-3 py-2">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_create')): ?>
        <div class="my-3">
            <a class="btn btn-success text-uppercase float-right" href="<?php echo e(route('dues.create')); ?>">
                <i class="fas fa-plus fa-fw"></i>
                <span class="big-btn-text">Add New Due</span>
            </a>
        </div>
        <?php endif; ?>
        <input type="text" id="searchBox" placeholder="🔍 Search the table below">
        <br>

        <div class="table-responsive">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th class="text-uppercase" scope="col">#</th>
                        <th class="text-uppercase" scope="col">Amount</th>
                        <th class="text-uppercase" scope="col">Payer</th>
                        <th class="text-uppercase" scope="col">Due Date</th>
                        <th class="text-uppercase" scope="col">Remark</th>
                        <th class="text-uppercase" scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $dues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $due): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($due->id); ?></td>
                        <td><?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?> <?php echo e($due->amount); ?></td>
                        <td><?php echo e($due->payer); ?></td>
                        <td><?php echo e($due->due_date->format('d-M-Y')); ?></td>
                        <td><?php echo e($due->remark); ?></td>
                        <td>
                            <div class="dropdown">
                                <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-boundary="viewport">
                                    ACTIONS
                                </a>
                                <div id="<?php echo e($due->id); ?>" class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_edit')): ?>
                                        <a role="button" class="mark-as-paid-btn dropdown-item text-primary">Mark as paid</a>
                                        <a class="dropdown-item text-primary"
                                            href="<?php echo e(route('dues.edit', ['id' => $due->id])); ?>">Edit</a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_delete')): ?>
                                    <div class="dropdown-divider"></div>
                                    <?php if(!$due->is_active): ?>
                                        <a role="button" class="entry-delete-btn dropdown-item text-danger" style="">
                                            Delete This due
                                        </a>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <input type="hidden" id="payurl<?php echo e($due->id); ?>" value="<?php echo e(route('dues.pay', ['id' => $due->id])); ?>">
                    <input type="hidden" id="deleteUrl<?php echo e($due->id); ?>" value="<?php echo e(route('dues.destroy', ['id' => $due->id])); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <input type="hidden" id="deletedBtnText" value="Yes, delete it!">
                    <input type="hidden" id="deletedTitle" value="Deleted!">
                    <input type="hidden" id="deletedMsg" value="The selected due was successfully deleted.">

                </tbody>
            </table>
            <?php if(count($dues) < 1): ?>
                <div class="px-4 py-5 mx-auto text-secondary">
                    No results found!
                </div>
            <?php endif; ?>
        </div>

        
        <div class="mt-4">
            <?php echo e($dues->links()); ?>

        </div>

        <input type="hidden" id="closedRedirectUrl" value="<?php echo e(route('dues.index')); ?>">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/table_utils.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/delete_entry.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/due_payment.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/dues/index.blade.php ENDPATH**/ ?>