<html>
<head><title>A2P Realtech Pvt.Ltd. 2 Factor Authentication for Exporting Leads</title></head>
<body>
<p>Dear <?php echo e($name); ?></p>

<p>Please find the 2 factor authentication code for Exporting Leads for <?php echo e($username); ?></p>
<h2><?php echo e($code); ?></h2>

<p>Regards<br/>A2P Realtech</p>

</body>
</html><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/mail_leads_admin.blade.php ENDPATH**/ ?>