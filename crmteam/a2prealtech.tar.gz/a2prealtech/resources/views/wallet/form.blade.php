@if ($errors->any())
    <div class="border border-danger text-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

@csrf

<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="payer">User</label>
       <select class="form-control js-example-basic-single" id="user_id" name="user_id" required>
            @foreach ($users as $user)
                <option value="{{ $user->id }}" >
                    {{ $user->name }}
                </option>
            @endforeach
        </select>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="amount">Amount ({{ App\Lancer\Utilities::CURRENCY_SYMBOL }})</label>
        <input type="number" step="0.01" class="form-control text-capitalize" id="amount" name="amount"
        value="" required>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="payment_mode">Payment Mode</label>
        <select class="form-control js-example-basic-single" id="payment_mode" name="payment_mode" required>
            @foreach ($payment_modes as $payment_mode)
                <option value="{{ $payment_mode->id }}">
                    {{ $payment_mode->name }}
                </option>
            @endforeach
        </select>
    </div>
</div>



<div class="form-group">
    <input type="submit" class="btn btn-success" value="Add">
    <a class="btn btn-danger ml-3" href="{{ route('wallet.index') }}">Cancel</a>
</div>
